package com.todolist.repositories;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.todolist.entities.Task;

public class TaskRepository {
	private static final String FILE_PATH = "C:\\Users\\zisha\\Documents\\toDoListApp.txt";
	private final File file;
	
	public TaskRepository() {
		file = new File(FILE_PATH);
		createFile();
		
		try(BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = reader.readLine()) != null) {
				if (line.startsWith("Name")) {
					Task.tasks.add(line.substring(6));
				}
			}
		} catch(IOException ex) {
			ex.printStackTrace();
		}
	}
	
	private void createFile() {
		try {
			if (!file.exists()) {
				file.createNewFile();
				// isNew = true;
				System.out.println("File" + file + "has been created");
			} else {
				// isNew = false;
				System.out.println("File already exists");
			}
		} catch (IOException ex) {
			throw new RuntimeException("Failed to create user file" + ex);
		}
	}
	
	public void saveTask(Task task) throws IOException {
		try (PrintWriter writer = new PrintWriter(new FileWriter(file, true))){
			writer.println("Name: " + task.getName() +  "\r\n" + "Description: " + task.getDescription()
					+ "\r\n" + "Category: " + task.getCategory() + "\r\n" + "Date: " + task.getDueDate()
					+ "\r\n");
			writer.flush();
		}
	}
	
	public List<String[]> searchTasks(String query) {
		List<String[]> results = new ArrayList<>();
		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String[] task = new String[4];
			String line;
			while ((line = reader.readLine())!= null) {
				if (line.startsWith("Name") && line.substring(6).contains(query) ) {
					for (int i = 0; i <= 3; i++) {
						task[i] = line;
						String newLine = reader.readLine();
						line = newLine;
					}
					results.add(task);
				}
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return results;
	}
	
	public List<String> listTasks() {
		List<String> results = new ArrayList<>();
		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = reader.readLine())!= null) {
				results.add(line);
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return results;
	}
	
	public void updateTask(String query, String updateQuery, String insertQuery) {
		try {
			List<String> lines = new ArrayList<>();
			try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
				String line;
				while ((line = reader.readLine()) != null) {
					if (line.startsWith("Name") && line.substring(6).contains(query)) {
						for (int i = 0; i <= 3; i++ ) {
							if (line.startsWith(updateQuery)) {
								lines.add(updateQuery +": " + insertQuery);
								line = reader.readLine();
							} else if (line.startsWith("Date")) {
								lines.add(line);
							} else {
								lines.add(line);
								line = reader.readLine();
							}
						}
					} else {
						lines.add(line);
					}
				}
			} 
			
			try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
				for (String newLine : lines) {
					writer.write(newLine);
					writer.newLine();
					System.out.println(newLine);
				}
			} 
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public void deleteTask(String query) {
		try {
			List<String> lines = new ArrayList<>();
			try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
				String line;
				while ((line = reader.readLine()) != null) {
					if (line.startsWith("Name") && line.substring(6).contains(query)) {
						for (int i = 0; i < 3; i++) {
							reader.readLine();
						}
						//continue;
					} else {
						lines.add(line);
					}
				}
			}
			try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
				for (String newLine : lines) {
					writer.write(newLine);
					writer.newLine();
				}
			}
			
		} catch (IOException io) {
			io.printStackTrace();
		}
	}
}
