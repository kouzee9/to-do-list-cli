package com.todolist.client;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.todolist.entities.Task;
import com.todolist.repositories.TaskRepository;

public class ToDoClient {
	private TaskRepository repo;
	
	public ToDoClient() {
		repo = new TaskRepository();
	}
	
	// gathering inputs for creating tasks
	public void taskInputs() {
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("You have selected Create Task");
			
			System.out.println("Enter Task Name (or 0 to return to menu)");
			String name = reader.readLine();
			if (name.equals("0")) return;
			
			System.out.println("Enter details (or 0 to return to menu)");
			String details = reader.readLine();
			if (details.equals("0")) return;
			
			System.out.println("Enter categoary of task (or 0 to return to menu)");
			String category = reader.readLine();
			if (category.equals("0")) return;
			
			System.out.println("Enter due date format YYYY/MM/DD (or 0 to return to menu)");
			String dueDate = reader.readLine();
			if (dueDate.equals("0")) return;
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Date date = dateFormat.parse(dueDate);
			
			createTask(name, details, category, date);
		} catch (IOException ioException) {
			ioException.printStackTrace();
		} catch (ParseException pex) {
			pex.printStackTrace();
		}
	}
	
	//createTask
	public void createTask(String name, String description, String category, Date dueDate) throws IOException {
		Task newTask = new Task(name, description, category, dueDate);
		repo.saveTask(newTask);
	}
	
	// Gather user inputs for updating task
	public void updateInputs() {
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			
			System.out.println("You have selected 'Update Task'");
			System.out.println("enter task name to search");
			String query = reader.readLine();
			if (query.equals("0")) return;
			
			List<String[]> results = searchTask(query);
			for (String[] array : results) {
				for (String str : array) {
					System.out.println(str);
				}
			}
			System.out.println("What do you wish to update?");
			String updateQuery = reader.readLine();
			if (updateQuery.equals("0")) return;
			
			System.out.println("Enter the new information you wish to insert.");
			String insertQuery = reader.readLine();
			if (insertQuery.equals("0")) return;
			
			updateTask(query, updateQuery, insertQuery);
			System.out.println("Task successfully updated.");
		} catch (IOException io) {
			io.printStackTrace();
		}
	}
	
	public List<String[]> searchTask(String query) {
		return repo.searchTasks(query);
	}

	public void updateTask(String query, String updateQuery, String insert) {
		repo.updateTask(query, updateQuery, insert);
	}

	public List<String> listTasks() {
		return repo.listTasks();
	}
	
	public void deleteTask(String query) {
		repo.deleteTask(query);
	}


	
	//deleteTask
	
	//updateTask
	
	//readTask
	
	//listTasks
	
	//searchTask
	
	//filterTasks
	
}
