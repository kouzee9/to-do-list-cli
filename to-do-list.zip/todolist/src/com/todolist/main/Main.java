package com.todolist.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.todolist.client.ToDoClient;

public class Main {

	public static void main (String[] args) {
		ToDoClient client = new ToDoClient();
		boolean backToMainMenu = false;
		
		//Request user input for a specific command
		System.out.println("Enter one of the following options (enter number): ");
		System.out.print("1. Create Task\r\n" + "2. Update Task\r\n" + "3. List All Tasks\r\n" + "4. Delete task\r\n"
				+ "Enter 0 to exit the program \r\n");
		
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			while (true) {
				String line = reader.readLine();
				if (Integer.parseInt(line) >= 1 && Integer.parseInt(line) <= 4) {
					switch (line) {
						case "1":
							client.taskInputs();
							break;
						case "2":
							client.updateInputs();
							break;
						case "3":
							System.out.println("Here are all the tasks in your to do List:");
							System.out.println();
							List<String> tasks = client.listTasks();
							for (String str : tasks) {
								System.out.println(str);
							}
							break;
						case "4":
							System.out.println("You have selected to delete a task.");
							System.out.println("Enter the task you wish to delete");
							String deleteQuery = reader.readLine();
							client.deleteTask(deleteQuery);
							System.out.println("Task successfully deleted");
							break;
						case "0":
							System.out.println("Exiting program...");
							return;
						default:
							System.out.println("Please enter a valid option");
							break;
						}
						// Menu to choose another option
						System.out.println("Enter one of the following options (enter number): ");
						System.out.print("1. Create Task\r\n" + "2. Update Task\r\n" + "3. List All Tasks\r\n" + "4. Delete task\r\n"
								+ "Enter 0 to exit the program \r\n");
					} else if (Integer.parseInt(line) == 0) {
						System.out.println("Closing program...");
						return;
					} else {
						System.out.println("Please enter a valid command");
					}
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			} 
		}

}
